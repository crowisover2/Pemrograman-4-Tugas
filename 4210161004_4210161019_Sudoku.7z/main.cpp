#include "Board.h"

int main() {
	int a;
	Board the_board;
	the_board.Display();
	cin >> a;
}