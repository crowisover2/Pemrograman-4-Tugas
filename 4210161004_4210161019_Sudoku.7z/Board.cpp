#include "Board.h"

Board::Board(){
	int i_one=0, i_two=0, temp;
	
	for (int i = 0; i < 9; i++) {
		for (int a = 0; a < 9; a++) {
			board_array[i][a] = 0;
		}
	}

	while (true) {
		board_array[i_one][box_to_place[i_two]] = rand() % 9 + 1;
		i_two++;
		if (i_two % 3 == 0) {
			i_one++;
			if (i_one == 5) {
				temp = i_two+1;
				i_two = 0;
				break;
			}
		}
	}

	while (true) {
		board_array[i_one][box_to_place[temp]] = rand() % 9 + 1;
		i_two++;
		temp = temp + i_two;
		if (i_two % 4 == 0) {
			i_one++;
		}
		if (temp >= 32)break;
	}
}

void Board::Display() {
	int i = 0, a = 0, temp = 0, asal = 0;
		while (true) {
			temp = temp + a;
			cout << board_array[i][temp]<<" ";
			//cout <;
			if (a % 2 == 0 && a != 0) {
				i++;
				a = -1;
				temp = asal;
				cout << "  |  ";
			}
			if (i % 3 == 0 && i!=0) {
				cout <<endl;
				asal = asal + 3;
				i = 0;
				if (asal > 8)break;
			}
			a++;
		}
}