#include <iostream>
#include <queue>
#include <stack>
#include "Command.h"
using namespace std;

class Invoke : public Command {
private :
	stack<Command>en_command;
	queue<Command>de_command;
public:
	void execute();
	void undo();
	void push();
};