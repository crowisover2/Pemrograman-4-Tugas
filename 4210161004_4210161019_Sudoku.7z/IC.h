#include <iostream>
#include "Command.h"
#include "Board.h"
using namespace std;

class IC : public Command {
public:
	void fill_board(Board *board, int x, int y, int num);
};