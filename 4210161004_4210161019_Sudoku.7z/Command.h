class Command {
	virtual void execute();
	virtual void undo();
};