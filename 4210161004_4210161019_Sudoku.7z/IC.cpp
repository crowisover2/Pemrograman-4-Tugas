#include "IC.h"
void IC::fill_board(Board *board, int x, int y, int num) {
	void execute();
	void undo();
}