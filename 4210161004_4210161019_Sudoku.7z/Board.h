#include <iostream>
#include <string>
using namespace std;

class Board{
	int board_array[9][9];
	int box_to_place[32] = {
		3, 6, 7,
		0, 1, 3,
		0, 4, 6,
		0, 1, 5,
		0, 5, 6, 8,
		2, 4, 6, 7,
		1, 3, 5, 8,
		0, 1, 3, 7,
		0, 1, 3, 6,
	};
public :
	Board();
	void Display();
};