#include "Lingkaran.h"
#include "persegi.h"
#include "Segitiga.h"

int main() {
	Lingkaran a;
	Segitiga b;
	Persegi c;

	a.luas(7);
	a.keliling(7);

	b.luas(4, 3);
	b.keliling(4, 3);

	c.luas(10, 5);
	c.keliling(10, 5);

	cout << "Luas Lingkaran : " << a.luasnya << endl;
	cout << "Keliling Lingkaran : " << a.kelilingnya << endl;

	cout << "Luas Segitiga : " << b.luasnya << endl;
	cout << "Keliling Segitiga : " << b.kelilingnya << endl;

	cout << "Luas Persegi : " << c.luasnya << endl;
	cout << "Keliling Persegi : " << c.kelilingnya << endl;
	cin >> a.kelilingnya;
}