#include<iostream>
#include "Lingkaran.h"

	void Lingkaran::luas(float jari_jari) {
		luasnya = jari_jari * jari_jari * 22 / 7;
	}

	void Lingkaran::keliling(float jari_jari) {
		kelilingnya = jari_jari * 2 * 22 / 7;
	}
