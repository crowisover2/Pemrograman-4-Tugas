#ifndef SEGITIGA_H
#define SEGITIGA_H
#include<iostream>
#include "BangunDatar.h"

class Segitiga : public BangunDatar {
public:
	float luasnya;
	float kelilingnya;

	void luas(float alas, float tinggi);

	void keliling(float alas, float tinggi);
};
#endif