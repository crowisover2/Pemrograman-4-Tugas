#include<iostream>
#include "Segitiga.h"

void Segitiga::luas(float alas, float tinggi) {
	luasnya = alas * tinggi * 1 / 2;
}

void Segitiga::keliling(float alas, float tinggi) {
	float a = pow(alas, 2);
	float b = pow(tinggi, 2);
	float miring = sqrt(a + b);

	kelilingnya = alas + 2 * miring;
}