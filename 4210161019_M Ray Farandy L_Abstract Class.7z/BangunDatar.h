#ifndef BANGUNDATAR_H
#define BANGUNDATAR_H
#include <iostream>
using namespace std;

class BangunDatar {
public:
	virtual void luas() {}
	virtual void keliling(){}
};
#endif