#ifndef LINGKARAN_H
#define LINGKARAN_H
#include<iostream>
#include "BangunDatar.h"

class Lingkaran : public BangunDatar {
public :
	float luasnya, kelilingnya;
	void luas(float jari_jari);
	void keliling(float jari_jari);
};
#endif