#include<iostream>
#include "persegi.h"

	void Persegi::luas(float panjang, float tinggi) {
		luasnya = panjang * tinggi;
	}

	void Persegi::keliling(float panjang, float tinggi) {
		kelilingnya = (panjang + tinggi) * 2;
	}
