#ifndef PERSEGI_H
#define PERSEGI_H
#include<iostream>
#include "BangunDatar.h"

class Persegi : public BangunDatar{
public:
	float luasnya;
	float kelilingnya;

	void luas(float panjang, float tinggi);

	void keliling(float panjang, float tinggi);
};
#endif