#include <stack>
using namespace std;
class Undo {
private:
	stack<int>box;
public:
	void InputedChar(int a) {
		box.push(a);
	}
	int get_last_char() {
		int b = box.top();
		box.pop();
		return b;
	}
	int the_size() {
		return box.size();
	}
};