#include<iostream>
#include<filesystem>
#include<conio.h>
#include"Undo.h"
using namespace std;


int main()
{
	static int i, operators = NULL;
	static string quest;
	while (1)
	{
		if (kbhit() != 0) {
			i = getch();
			
			if (i >= 48 && i <= 57) {
				cout << char(i) << endl;

			}
				else if (i == 42) { // times *
					cout << char(i) << endl;
					operators = i;
				}
				else if (i == 45) { // minus -
					cout << char(i) << endl;
					operators = i;
				}
				else if (i == 43) { // plus +
					cout << char(i) << endl;
					operators = i;
				}
				else if (i == 47) { //divide /
					cout << char(i) << endl;
					operators = i;
				}
				else if (i == 33) { // delete, press shift+1
					system("cls");

				}
		}
	}
	std::cin >> i;

}