#include<iostream>
#include<string>
#include<filesystem>
#include<conio.h>
#include"Undo.h"
using namespace std;


int main()
{
	static int i, operators = NULL;
	vector<int>quest;
	string a [2];
	Undo unedo;
	cout << "press shift+1 to delete" << endl;
	cout << "press shift+2 to undo" << endl;
	
	while (1)
	{
		if (kbhit() != 0) {
			i = getch();
			
			if (i >= 48 && i <= 57) {
				cout << char(i);
				quest.push_back(i);
			}
				else if (i == 42) { // times *
					cout << char(i);
					operators = i;
					quest.push_back(i);
				}
				else if (i == 45) { // minus -
					cout << char(i);
					operators = i;
					quest.push_back(i);
				}
				else if (i == 43) { // plus +
					cout << char(i);
					operators = i;
					quest.push_back(i);
				}
				else if (i == 47) { //divide /
					cout << char(i);
					operators = i;
					quest.push_back(i);
				}
				else if (i == 33) { // delete, press shift+1
					system("cls");
					cout << "press shift+1 to delete" << endl;
					cout << "press shift+2 to undo" << endl;
					unedo.InputedChar(quest.back());
					quest.pop_back();
					for (int n : quest) {
						cout << char(n);
					}
				}
				else if (i == 64) { // delete, press shift+1
					system("cls");
					cout << "press shift+1 to delete" << endl;
					cout << "press shift+2 to undo" << endl;
					quest.push_back(unedo.get_last_char());
					for (int n : quest) {
						cout << char(n);
					}
				}
				else if (i == 13) {
					break;
				}
				//else cout << endl << getch() << endl;
		}
	}

	int temp = 0;
	for (int n : quest) {
		if (n >= 48 && n <= 57)a[temp] = a[temp] + char(n);
		else temp++;
	}

	int alpha = stoi(a[0]);
	int beta = stoi(a[1]);
	if (operators == 42) { // times *
		cout << endl<<(alpha * beta);
	}
	else if (operators == 45) { // minus -
		cout << endl<<(alpha - beta);
	}
	else if (operators == 43) { // plus +
		cout << endl<<(alpha + beta);
	}
	else if (operators == 47) { //divide /
		cout << endl<<(alpha / beta);
	}

	//std::cin >> i;
}