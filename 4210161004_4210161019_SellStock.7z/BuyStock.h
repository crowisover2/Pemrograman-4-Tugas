#ifndef BUYSTOCK_H
#define BUYSTOCK_H
#include <iostream>
#include "Order.h"
#include "Stock.h"
using namespace std;

class buystock : public order, public Stock{
private :
	Stock abcStock;
public:
	buystock(Stock abcStock);
	void execute();
};

#endif