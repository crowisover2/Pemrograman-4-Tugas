#ifndef ORDER_H
#define ORDER_H
#include <iostream>
using namespace std;

class order {
public:
	virtual void execute();
};

#endif