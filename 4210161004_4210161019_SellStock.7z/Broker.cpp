#include "Broker.h"

void Broker::takeOrder(order _order) {
		orderList.push_back(_order);
}

void Broker::placeOrders() {

	for (order _order : orderList) {
		_order.execute();
	}

	orderList.empty();
}