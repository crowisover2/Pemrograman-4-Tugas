#ifndef BROKER_H
#define BROKER_H
#include <iostream>
#include <queue>
#include "SellStock.h"
#include "BuyStock.h"
using namespace std;

class Broker {
	deque<order>orderList;

public:
	void takeOrder(order _order);
	void placeOrders();
};
#endif

