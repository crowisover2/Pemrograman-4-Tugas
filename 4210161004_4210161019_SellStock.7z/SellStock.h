#ifndef SELLSTOCK_H
#define SELLSTOCK_H
#include <iostream>
#include "Order.h"
#include "Stock.h"
using namespace std;

class sellstock : public order, public Stock{
private:
	Stock abcStock;
public:
	sellstock(Stock abcStock);
	void execute();
};

#endif
