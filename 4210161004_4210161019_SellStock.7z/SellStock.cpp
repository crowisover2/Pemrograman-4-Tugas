#include "SellStock.h"

sellstock::sellstock(Stock abcStock) {
	this->abcStock = abcStock;
}
void sellstock::execute() {
	abcStock.sell();
}
