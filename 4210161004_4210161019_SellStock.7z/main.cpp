#include <iostream>
#include "Stock.h"
#include "Broker.h"
using namespace std;

int main() {
	
	Stock abcStock;
	buystock buyStockOrder (abcStock);
	sellstock sellStockOrder (abcStock);

	Broker broker;
	broker.takeOrder(buyStockOrder);
	broker.takeOrder(sellStockOrder);

	broker.placeOrders();
}