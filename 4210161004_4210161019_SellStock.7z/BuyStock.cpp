#include "BuyStock.h"

buystock::buystock(Stock abcStock) {
		this->abcStock = abcStock;
}
void buystock::execute() {
		abcStock.buy();
}