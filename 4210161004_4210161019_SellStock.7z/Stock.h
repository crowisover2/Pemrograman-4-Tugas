#ifndef STOCK_H
#define STOCK_H
#include <iostream>
#include <string>
using namespace std;

class Stock {
private :
	string name = "ABC";
	int quantity = 10;
public :
	void buy();
	void sell();
};

#endif